<?php
ob_start();
session_start();
include_once '../initialize.php';
	$TitelItem 		= 'DockX';
	$ogurlItem 		= 'https://teacher-ip.com/tools/DockX';
	$ogimageItem 	= 'https://teacher-ip.com/style/photo/itame/DockX.png';
	$ogtypeItem 	= 'article';
	if ($_COOKIE['lang']=='en') {
		$keywordsItem 		= 'Tools, DockX, Zebra, ios, Sileo, Installer, Cydia, Jailbreak tools, Tools iPhone';
		$descriptionItem 	= 'Upgrade your iPhone’s native keyboard with DockX';
		$authorItem 		= 'Sultan AL-Otaibi';
		$ogtitle 			= 'TinyBanners';
		$ogdescriptionI 	= 'Upgrade your iPhone’s native keyboard with DockX';
		$oglocaleItem 		= 'en_US';
	}else{
		$keywordsItem 		= 'ادوات حماية ، ادوات جلبريك ، حماية جهازك ، سيديا ، تحميل ادوات ، سورسات ادوات';
		$descriptionItem 	= 'قم بترقية لوحة المفاتيح الأصلية لجهاز iPhone باستخدام DockX';
		$authorItem 		= 'سلطان العتيبي';
		$ogtitle 			= 'DockX';
		$ogdescriptionI 	= 'قم بترقية لوحة المفاتيح الأصلية لجهاز iPhone باستخدام DockX';
		$oglocaleItem 		= 'ar_SA';
	}
	header_Tag( $TitelItem.$lang['Lang_title2'],
				$keywordsItem,
				$descriptionItem,
				$authorItem,
				$ogtitle.$lang['Lang_title2'],
				$ogdescriptionI,
				$ogurlItem,
				$ogimageItem,
				$ogtypeItem,
				$oglocaleItem
			);
// Databases;
	$ImageItem 		= 'DockX.png';
	$NameItemX 		= 'DockX';
	$DescriptionX 	= $lang['Lang_T_D_TinyDockX'];
	$Url_cydia		= 'cydia://url/https://cydia.saurik.com/api/share#?source=https://repo.packix.com/';
	$Url_installer	= 'installer://add/repo=https://repo.packix.com/';
	$Url_sileo		= 'sileo://source/https://repo.packix.com/';
	$Url_zbra		= 'zbra://sources/add/https://repo.packix.com/';
	$PRICE_X 		= $lang['Lang_FREEI'];
	$RELEASED_X		= '2020-9-19';
	$VERSION_X 		= '1.4';
	$Repository_X 	= 'Packix';
	$Repository_XUrl= 'https://repo.packix.com/';
	$Developer_X 	= 'Mudi4_7';
	$Source_code_X	= 'Github';
	$Sourcecode_XUrl= 'https://github.com/mudi47';
	$Image_View_1 	= 'DockX_1.png';
	$Image_View_2 	= 'DockX_2.png';
	$Image_View_3 	= 'DockX_3.png';
	$Image_View_4 	= 'DockX_4.png';
?>
	<div class="sb-nav-tabs-wrapper">
		<div class="container">
			<ul class="nav nav-tabs sb-nav-tabs border-0">
				<img src="<?php echo $img; ?>itame/<?php echo $ImageItem; ?>" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="<?php echo $NameItemX; ?>" title="<?php echo $NameItemX; ?>" style="width: 60px; height: 60px;position: absolute;">
				<li class="nav-item">
					<a class="nav-link nav-link-theme active">
						<h1 class="font-weight-bold"><?php echo $NameItemX; ?></h1>
					</a>
				</li>
			</ul>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-lg-8 mb-3">
				<div class="card shadow">
					<h6 class="card-header font-weight-bold text-justify"><?php echo $lang['Lang_T_Description']; ?></h6>
					<div class="card-body">
						<p class="card-text text-justify font-weight-normal">
							<?php echo $DescriptionX; ?>
						</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 mb-3">
				<div class="card shadow">
					<div class="card-body">
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="<?php echo $Url_cydia; ?>" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/cydia.png" alt="Cydia" class="rounded-circle"><?php echo $lang['Lang_Cydia'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="<?php echo $Url_installer; ?>" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/installer.png" alt="Installer" class="rounded-circle"><?php echo $lang['Lang_Installer'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="<?php echo $Url_sileo; ?>" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/sileo.png" alt="Sileo" class="rounded-circle"><?php echo $lang['Lang_Sileo'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="<?php echo $Url_zbra; ?>" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/zebra.png" alt="Zebra" class="rounded-circle"><?php echo $lang['Lang_Zebra'] ?></a>
					</div>
				</div>
			</div>
			<div class="col-lg-8 mb-3">
				<div class="row text-center text-lg-left">
					<div class="col-lg-4 col-md-4 col-6">
						<img class="img-fluid img-thumbnail" src="<?php echo $UrlXp; ?>images/<?php echo $Image_View_1; ?>" alt="<?php echo $NameItemX; ?>_1" title="<?php echo $NameItemX; ?> 1">
					</div>
					<div class="col-lg-4 col-md-4 col-6">
						<img class="img-fluid img-thumbnail" src="<?php echo $UrlXp; ?>images/<?php echo $Image_View_2; ?>" alt="<?php echo $NameItemX; ?>_2" title="<?php echo $NameItemX; ?> 2">
					</div>
					<div class="col-lg-4 col-md-4 col-6">
						<img class="img-fluid img-thumbnail" src="<?php echo $UrlXp; ?>images/<?php echo $Image_View_3; ?>" alt="<?php echo $NameItemX; ?>_3" title="<?php echo $NameItemX; ?> 3">
					</div>
					<div class="col-lg-4 col-md-4 col-6">
						<img class="img-fluid img-thumbnail" src="<?php echo $UrlXp; ?>images/<?php echo $Image_View_4; ?>" alt="<?php echo $NameItemX; ?>_4" title="<?php echo $NameItemX; ?> 4">
					</div>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="card shadow mt-3 mb-3">
					<div class="card-body">
						<div class="d-flex justify-content-between small">
							<span class="font-weight-bold"><?php echo $lang['Lang_T_PRICE']; ?></span>
							<span class="font-weight-bold text-success"><?php echo $PRICE_X; ?></span>
						</div>
						<hr class="my-2">
						<div class="d-flex justify-content-between small">
							<span class="font-weight-bold"><?php echo $lang['Lang_T_RELEASED']; ?></span>
							<span class="font-weight-bold">
								<time datetime="<?php echo $RELEASED_X; ?>"><?php echo $RELEASED_X; ?></time>
							</span>
						</div>
						<hr class="my-2">
						<div class="d-flex justify-content-between small">
							<span class="font-weight-bold"><?php echo $lang['Lang_T_VERSION']; ?></span>
							<span class="font-weight-bold"><?php echo $VERSION_X; ?></span>
						</div>
						<hr class="my-2">
						<div class="d-flex justify-content-between small">
							<span class="font-weight-bold"><?php echo $lang['Lang_T_Repository']; ?></span>
							<span><a class="font-weight-bold" href="<?php echo $Repository_XUrl; ?>" title="<?php echo $Repository_X; ?>" target="_blank"><?php echo $Repository_X; ?></a></span>
						</div>
						<hr class="my-2">
						<div class="d-flex justify-content-between small">
							<span class="font-weight-bold"><?php echo $lang['Lang_T_Developer']; ?></span>
							<span class="font-weight-bold"><?php echo $Developer_X; ?></span>
						</div>
						<hr class="my-2">
						<div class="d-flex justify-content-between small">
							<span class="font-weight-bold"><?php echo $lang['Lang_T_Source']; ?></span>
							<span><a class="font-weight-bold" href="<?php echo $Sourcecode_XUrl; ?>" title="<?php echo $Source_code_X; ?>" target="_blank"><?php echo $Source_code_X; ?></a></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
include_once '../include/templates/footer.php';
ob_end_flush();
?>