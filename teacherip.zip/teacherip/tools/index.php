<?php
ob_start();
session_start();
include_once '../initialize.php';
	$ogurlItem 		= 'https://teacher-ip.com/tools/';
	$ogimageItem 	= 'https://teacher-ip.com/tools/images/tools.png';
	$ogtypeItem 	= 'website';
	header_Tag( $lang['Lang_TITnITLE'].' | '.$lang['Lang_Title'],
				$lang['Lang_TIkeywords'],
				$lang['Lang_TIdescript'],
				$lang['Lang_TIauthor'],
				$lang['Lang_TIogtitle'],
				$lang['Lang_TIogdescrip'],
				$ogurlItem,
				$ogimageItem,
				$ogtypeItem,
				$lang['Lang_TIoglocale']
			);
?>
	<div class="sb-nav-tabs-wrapper">
		<div class="container">
			<ul class="nav nav-tabs sb-nav-tabs border-0">
				<img src="<?php echo $UrlXp; ?>images/tools.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="Cinque Terre" style="width: 60px; height: 60px;position: absolute;">
				<li class="nav-item">
					<a class="nav-link nav-link-theme active" style="margin-left: 50px;">
						<h1 class="font-weight-bold">
							<?php echo $lang['Lang_TIH1title']; ?>
						</h1>
					</a>
				</li>
			</ul>
		</div>
	</div>
	<?php 
	if ($_COOKIE['lang']=='en') {
		$Items1 		= 'Lock apps with fingerprint or control center items, Wi-Fi, and more.';
		$Items2 		= 'Minimize notifications in the bar and lock screen Control color the notification Control the display.';
		$Items3 		= 'Add shortcuts to the bottom of the keyboard, copy, paste, select, and much more';
		$Items4 		= 'Tool function Change your voice to several voices during the call, compatible with | ios11';
		$Items5 		= 'It gives you an application icon in the main screen with a library full of sursat inside';
		$Items6 		= 'The best tool for Instagram';
	}else{
		$Items1 		= 'قفل التطبيقات باستخدام بصمة الإصبع أو عناصر مركز التحكم وشبكة Wifi والمزيد.';
		$Items2 		= 'تصغير الإشعارات في الشريط وشاشة القفل التحكم في لون الإخطار التحكم في العرض.';
		$Items3 		= 'أضف اختصارات إلى الجزء السفلي من لوحة المفاتيح وانسخها والصقها وحددها وغير ذلك الكثير';
		$Items4 		= 'وظيفة الأداة قم بتغيير صوتك إلى عدة أصوات أثناء المكالمة ، متوافقة مع | iOS 11';
		$Items5 		= 'يمنحك أيقونة تطبيق في الشاشة الرئيسية مع مكتبة مليئة بالسور بالداخل';
		$Items6 		= 'أفضل أداة لـ Instagram';
	}
	?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 mb-3">
				<div class="list-group text-justify font-weight-normal">
					<a href="<?php echo $UrlXp; ?>A-Shields" class="list-group-item list-group-item-action flex-column align-items-start">
						<img src="<?php echo $img; ?>itame/A-Shields.png" class="box-shadow bg-white rounded-circle text-center" alt="A-Shields" style="width: 45px; height: 45px;position: absolute;">
						<div class="d-flex w-100 justify-content-between">
							<h5 class="mb-1 <?php echo $lang['Lang_ML_Lang']; ?>-5 font-weight-bold">A-Shields</h5>
							<small class="text-muted">2020-9-19</small>
						</div>
						<small class="text-muted <?php echo $lang['Lang_ML_Lang']; ?>-5"><?php echo $Items1; ?></small>
					</a>
					<a href="<?php echo $UrlXp; ?>TinyBanners" class="list-group-item list-group-item-action flex-column align-items-start pricexp">
						<img src="<?php echo $img; ?>itame/TinyBanners.png" class="box-shadow bg-white rounded-circle text-center" alt="TinyBanners" style="width: 45px; height: 45px;position: absolute;">
						<div class="d-flex w-100 justify-content-between">
							<h5 class="mb-1 <?php echo $lang['Lang_ML_Lang']; ?>-5 font-weight-bold">TinyBanners</h5>
							<small class="text-muted">2020-9-19</small>
						</div>
						<small class="text-muted <?php echo $lang['Lang_ML_Lang']; ?>-5"><?php echo $Items2; ?></small>
					</a>
					<a href="<?php echo $UrlXp; ?>DockX" class="list-group-item list-group-item-action flex-column align-items-start">
						<img src="<?php echo $img; ?>itame/DockX.png" class="box-shadow bg-white rounded-circle text-center" alt="DockX" style="width: 45px; height: 45px;position: absolute;">
						<div class="d-flex w-100 justify-content-between">
							<h5 class="mb-1 <?php echo $lang['Lang_ML_Lang']; ?>-5 font-weight-bold">DockX</h5>
							<small class="text-muted">2020-9-19</small>
						</div>
						<small class="text-muted <?php echo $lang['Lang_ML_Lang']; ?>-5"><?php echo $Items3; ?></small>
					</a>
					<a href="<?php echo $UrlXp; ?>VoiceChangerX" class="list-group-item list-group-item-action flex-column align-items-start pricexp">
						<img src="<?php echo $img; ?>itame/VoiceChangerX.png" class="box-shadow bg-white rounded-circle text-center" alt="VoiceChangerX" style="width: 45px; height: 45px;position: absolute;">
						<div class="d-flex w-100 justify-content-between">
							<h5 class="mb-1 <?php echo $lang['Lang_ML_Lang']; ?>-5 font-weight-bold">VoiceChanger XS (iOS 11/12/13)</h5>
							<small class="text-muted">2020-9-19</small>
						</div>
						<small class="text-muted <?php echo $lang['Lang_ML_Lang']; ?>-5"><?php echo $Items4; ?></small>
					</a>
					<a href="<?php echo $UrlXp; ?>RepoFinder" class="list-group-item list-group-item-action flex-column align-items-start">
						<img src="<?php echo $img; ?>itame/RepoFinder.png" class="box-shadow bg-white rounded-circle text-center" alt="BioProtect_X" style="width: 45px; height: 45px;position: absolute;">
						<div class="d-flex w-100 justify-content-between">
							<h5 class="mb-1 <?php echo $lang['Lang_ML_Lang']; ?>-5 font-weight-bold">RepoFinder</h5>
							<small class="text-muted">2020-9-19</small>
						</div>
						<small class="text-muted <?php echo $lang['Lang_ML_Lang']; ?>-5"><?php echo $Items5; ?></small>
					</a>
					<a href="<?php echo $UrlXp; ?>Rhino" class="list-group-item list-group-item-action flex-column align-items-start">
						<img src="<?php echo $img; ?>itame/Rhino.png" class="box-shadow bg-white rounded-circle text-center" alt="Rhino" style="width: 45px; height: 45px;position: absolute;">
						<div class="d-flex w-100 justify-content-between">
							<h5 class="mb-1 <?php echo $lang['Lang_ML_Lang']; ?>-5 font-weight-bold">Rhino</h5>
							<small class="text-muted">2020-9-19</small>
						</div>
						<small class="text-muted <?php echo $lang['Lang_ML_Lang']; ?>-5"><?php echo $Items6; ?></small>
					</a>
				</div>
			</div>
		</div>
	</div>
<?php
include_once '../include/templates/footer.php';
ob_end_flush();
?>