<?php
include_once 'connect.php';
$UrlXp		= "http://".$_SERVER["SERVER_NAME"].substr($_SERVER["PHP_SELF"],0,strrpos($_SERVER["PHP_SELF"],"/"))."/";
$function	= 'include/function/';
$language	= 'include/language/';
$templates	= 'include/templates/';
$img		= $UrlXp.'style/photo/';
$css		= $UrlXp.'style/stylesheets/';
$js 		= $UrlXp.'style/javascript/';
include_once $function.'function.php';
include_once $language.'language.php';
include_once $templates.'header.php';
if(!isset($noNavbar)){include_once $templates . 'navbar.php';}