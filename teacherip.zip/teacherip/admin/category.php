<?php
ob_start();
session_start();
if (isset($_SESSION['Username'])) {
	include_once 'initialize.php';
	ch_title($lang['Lang_Dashboard']);
	echo '<div id="content-wrapper"><div class="container-fluid">';
	
	$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';
	if ($do == 'Manage') {
		$stmt2 = $con->prepare("SELECT * FROM categories ORDER BY cat_id DESC");
		$stmt2->execute();
		$cats = $stmt2->fetchAll();
		?>
		<div class="card">
			<h5 class="card-header"><i class="fas fa-puzzle-piece"></i> Manage Category</h5>
			<div class="card-body p-0">
				<ul class="list-group list-group-flush">
					<?php
						foreach ($cats as $cat) {
					?>
					<li class="list-group-item justify-content-between align-items-center">
						<div class="product-img">
							<img src="style/photo/description.png" alt="Product Image">
						</div>
						<div class="product-info">
							<a href="category.php?do=Edit&catid=<?php echo $cat['cat_id']; ?>" class="product-title"><?php echo $cat['cat_name']; ?></a>
							<a class="btn btn-danger btn-sm float-right ml-2" href="category.php?do=Delete&catid=<?php echo $cat['cat_id']; ?>" role="button"><i class="fas fa-trash-alt"></i> Delete</a>
							<a class="btn btn-primary btn-sm float-right" href="category.php?do=Edit&catid=<?php echo $cat['cat_id']; ?>" role="button"><i class="fas fa-edit"></i> Edit</a>
							
							
							<span class="product-description">
								<?php
									if (empty($cat['cat_description'])) {
										echo 'Empty Description';
									}else{
										echo $cat['cat_description'];
									}
									
								?>
							</span>
						</div>
					</li>
					<?php	
						}
					?>
				</ul>
			</div>
		</div>
		<a href="category.php?do=Add" class="btn btn-primary mt-2"><i class="fas fa-plus"></i> Add New Category</a>
		<?php
	}elseif ($do == 'Add') {
		?>
		<div class="card">
			<h5 class="card-header"><i class="fas fa-puzzle-piece"></i> Add New Category</h5>
			<div class="card-body">
				<form action="?do=Insert" method="POST">
					<div class="text-center">
						<img src="style/photo/description.png" class="rounded" alt="Cinque Terre" width="150" height="150">
					</div>
					<div class="form-row">
						<div class="form-group col-md-6">
							<label for="inputName"><i class="fas fa-building"></i> Name</label>
							<input type="text" name="name" class="erorrJS form-control" id="inputName" placeholder="Name The Category" required>
						</div>
						<div class="form-group col-md-6">
							<label for="inputOrdering"><i class="fas fa-user"></i> Ordering</label>
							<input type="text" name="ordering" class="form-control" id="inputOrdering" placeholder="Number The Category Ordering" value="1">
						</div>
						<div class="form-group col-md-12">
							<label for="inputDescription"><i class="fas fa-audio-description"></i> Description</label>
							<input type="text" name="description" class="form-control" id="inputDescription" placeholder="Description The Category">
						</div>
					</div>
					<button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add New Category</button>
				</form>
			</div>
		</div>
		<?php
	}elseif ($do == 'Insert') {
		echo '<div class="card"><h5 class="card-header"><i class="fas fa-radiation"></i> Administrative message</h5><div class="card-body">';
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$name 	 	= $_POST['name'];
			$ordering 	= $_POST['ordering'];
			$desc 		= $_POST['description'];
			$check 	= checkItem('cat_name', 'categories', $name);
			if ($check == 1) {
				echo '<div class="alert alert-danger" role="alert"><i class="fas fa-times"></i> Categories exists, please choose another Categories</div>';
			}else{
				$stmt 	= $con->prepare("INSERT INTO categories(cat_name, cat_description, cat_ordering) VALUES(:zname, :zdesc, :zorder)");
				$stmt->execute(array(
									'zname' 	=> $name,
									'zdesc' 	=> $desc,
									'zorder' 	=> $ordering,
									));
				echo '<div class="alert alert-success" role="alert"><i class="fas fa-check"></i> The Categories was added successfully</div>';
				echo '</div></div>';
			}
		}else{
			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation"></i> Error</div>';
		}
	}elseif ($do == 'Edit') {
		$catid 	= isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
		$stmt 	= $con->prepare("SELECT * FROM categories WHERE cat_id = ?");
		$stmt->execute(array($catid));
		$cat 	= $stmt->fetch();
		$count 	= $stmt->rowCount();
		if ($count > 0) {
			?>
			<div class="card">
				<h5 class="card-header"><i class="fas fa-edit"></i> Edit Category</h5>
				<div class="card-body">
					<form action="?do=Insert" method="POST">
						<input type="hidden" name="catid" value="<?php echo $cat_id; ?>">
						<div class="text-center">
							<img src="style/photo/description.png" class="rounded" alt="Cinque Terre" width="150" height="150">
						</div>
						<div class="form-row">
							<div class="form-group col-md-6">
								<label for="inputName"><i class="fas fa-building"></i> Name</label>
								<input type="text" name="name" class="erorrJS form-control" id="inputName" placeholder="Name The Category" required value="<?php echo $cat['cat_name']; ?>">
							</div>
							<div class="form-group col-md-6">
								<label for="inputOrdering"><i class="fas fa-user"></i> Ordering</label>
								<input type="text" name="ordering" class="form-control" id="inputOrdering" placeholder="Number The Category Ordering" value="<?php echo $cat['cat_ordering']; ?>">
							</div>
							<div class="form-group col-md-12">
								<label for="inputDescription"><i class="fas fa-audio-description"></i> Description</label>
								<input type="text" name="description" class="form-control" id="inputDescription" placeholder="Description The Category" value="<?php echo $cat['cat_description']; ?>">
							</div>
						</div>
						<button type="submit" class="btn btn-primary"><i class="fas fa-edit"></i> Edit Category</button>
					</form>
				</div>
			</div>
			<?php
		}else{
			echo '<div class="card"><h5 class="card-header"><i class="fas fa-radiation"></i> Administrative message</h5><div class="card-body">';
			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation"></i> Message Error Cat ID</div>';
			echo '</div></div>';
		}
	}elseif ($do == 'Update') {
		echo '<div class="card"><h5 class="card-header"><i class="fas fa-radiation"></i> Administrative message</h5><div class="card-body">';
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$id 	= $_POST['catid'];
			$name 	= $_POST['name'];
			$order 	= $_POST['ordering'];
			$des 	= $_POST['description'];
			
			$stmt 	= $con->prepare("UPDATE categories SET cat_name = ?, cat_description = ?, cat_ordering = ? WHERE cat_id = ?");
			$stmt->execute(array($name, $order, $des, $id));
			echo '<div class="alert alert-success" role="alert"><i class="fas fa-check"></i> The data was successfully updated</div>';
			echo '</div></div>';

		}else{
			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation"></i> Error</div>';
		}
	}elseif ($do == 'Delete') {
		$catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
		$check 	= checkItem('cat_id', 'categories', $catid);
		if ($check > 0) {
			$stmt = $con->prepare("DELETE FROM categories WHERE cat_id = :zid");
			$stmt->bindParam(":zid", $catid);
			$stmt->execute();
		}else{
			echo 'This ID Is Not Exist';
		}
	}

	echo'</div></div></div>';
	include_once $templates.'footer.php';
}else{
	header('Location: index.php');
	exit();
}
ob_end_flush();
?>