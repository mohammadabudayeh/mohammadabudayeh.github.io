<?php
ob_start();
session_start();
if (isset($_SESSION['Username'])) {
	include_once 'initialize.php';
	ch_title($lang['Lang_Dashboard']);
?>
	<div id="content-wrapper">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-12">
					<div class="card text-white bg-info card-dash">
						<div class="card-body">
							<h3 class="card-title"><?php echo countItems('user_id', 'users'); ?></h3>
							<p class="card-text">Users</p>
							<div class="icon">
								<i class="fas fa-users"></i>
							</div>
						</div>
						<a href="members.php" class="card-footer text-center text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<div class="card text-white bg-success card-dash">
						<div class="card-body">
							<h3 class="card-title">20</h3>
							<p class="card-text">Topics</p>
							<div class="icon">
								<i class="fas fa-newspaper"></i>
							</div>
						</div>
						<a href="#" class="card-footer text-center text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<div class="card text-white bg-warning card-dash">
						<div class="card-body">
							<h3 class="card-title">500</h3>
							<p class="card-text">Comments</p>
							<div class="icon">
								<i class="fas fa-comments"></i>
							</div>
						</div>
						<a href="#" class="card-footer text-center text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
					</div>
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<div class="card text-white bg-danger card-dash">
						<div class="card-body">
							<h3 class="card-title">65</h3>
							<p class="card-text">Unique Visitors</p>
							<div class="icon">
								<i class="fas fa-chart-pie"></i>
							</div>
						</div>
						<a href="#" class="card-footer text-center text-white">More info <i class="fas fa-arrow-circle-right"></i></a>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-6 col-12 mb-2">
					<div class="card">
						<h5 class="card-header"><i class="fas fa-tags"></i> Latest topics added</h5>
						<div class="card-body p-0">
							<ul class="list-group list-group-flush">
								<li class="list-group-item justify-content-between align-items-center">
									<div class="product-img">
										<img src="../style/photo/itame/TinyBanners.png" alt="Product Image">
									</div>
									<div class="product-info">
										<a href="#" class="product-title">TinyBanners
											<span class="badge badge-warning float-right">$0.99</span>
										</a>
										<span class="product-description">
											Minimize notifications in the bar and lock screen Control color the notification Control the display.
										</span>
									</div>
								</li>
								<li class="list-group-item justify-content-between align-items-center">
									<div class="product-img">
										<img src="../style/photo/itame/BioProtect_X.png" alt="Product Image">
									</div>
									<div class="product-info">
										<a href="#" class="product-title">RepoFinder
											<span class="badge badge-primary float-right">Free</span>
										</a>
										<span class="product-description">
											It gives you an application icon in the main screen with a library full of sursat inside
										</span>
									</div>
								</li>
								<li class="list-group-item justify-content-between align-items-center">
									<div class="product-img">
										<img src="../style/photo/itame/A-Shields.png" alt="Product Image">
									</div>
									<div class="product-info">
										<a href="#" class="product-title">A-Shields
											<span class="badge badge-primary float-right">Free</span>
										</a>
										<span class="product-description">
											Lock apps with fingerprint or control center items, Wi-Fi, and more.
										</span>
									</div>
								</li>
								<li class="list-group-item justify-content-between align-items-center">
									<div class="product-img">
										<img src="../style/photo/itame/udevs.png" alt="Product Image">
									</div>
									<div class="product-info">
										<a href="#" class="product-title">DockX
											<span class="badge badge-primary float-right">Free</span>
										</a>
										<span class="product-description">
											Add shortcuts to the bottom of the keyboard, copy, paste, select, and much more
										</span>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-12 mb-2">
					<div class="card">
						<h5 class="card-header"><i class="fas fa-user"></i> The last registered members</h5>
						<div class="card-body p-0">
							<ul class="list-group list-group-flush">
							<?php
								$e = getLatest('*', 'users', 'user_id', 4);
								foreach ($e as $user) {	
							?>
								<li class="list-group-item justify-content-between align-items-center">
									<div class="product-img">
										<img src="<?php echo $user['avatar']; ?>" alt="Product Image">
									</div>
									<div class="product-info">
										<a href="members.php?do=Edit&userid=<?php echo $user['user_id']; ?>" class="product-title">
											<?php echo $user['user']; ?>
										</a>
										<span class="product-description">
											<?php echo $user['first_name'].' '.$user['last_name']; ?>
										</span>
									</div>
								</li>
							<?php
								}
							?>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div><!-- #wrapper -->
<?php
	include_once $templates.'footer.php';

}else{
	header('Location: index.php');
	exit();
}

ob_end_flush();
?>