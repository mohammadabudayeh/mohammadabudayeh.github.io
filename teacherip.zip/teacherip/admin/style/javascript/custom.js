// Loading
$(window).on("load",function() {
	$("#loading").fadeOut("slow");
});
$(function () {
	'use strict';    
	// Hide Placeholder On Form Focus
	$('[placeholder]').focus(function () {
		$(this).attr('data-text', $(this).attr('placeholder'));
		$(this).attr('placeholder', '');
	}).blur(function () {
		$(this).attr('placeholder', $(this).attr('data-text'));
	});
	// Toggle The Side Navigation
	$("#sidebarToggle").on('click', function(e) {
		e.preventDefault();
		$("body").toggleClass("sidebar-toggled");
		$(".sidebar").toggleClass("toggled");
	});
	// Show Error Form 
	$('.erorrJS').blur(function(){
		if ($(this).val()==='') {
			$(this).addClass('is-invalid');
		}else{
			$(this).addClass('is-valid');
			$(this).removeClass('is-invalid');
		}
	});
});