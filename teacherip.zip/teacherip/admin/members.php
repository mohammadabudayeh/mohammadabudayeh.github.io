<?php
ob_start();
session_start();
if (isset($_SESSION['Username'])) {
	include_once 'initialize.php';
	ch_title($lang['Lang_Dashboard']);
	echo '<div id="content-wrapper"><div class="container-fluid">';
	$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';
	if ($do == 'Manage') {
		$stmt = $con->prepare("SELECT * FROM users");
		$stmt->execute();
		$rows = $stmt->fetchAll();
		?>
		<div class="card">
			<h5 class="card-header"><i class="fas fa-users"></i> Manage Members</h5>
			<div class="card-body p-0">
				<div class="table-responsive">
					<table class="table table-hover m-0">
						<thead>
							<tr>
								<th scope="col"><i class="fas fa-fingerprint"></i> #</th>
								<th scope="col"><i class="fas fa-user-secret"></i> Username</th>
								<th scope="col"><i class="fas fa-user"></i> First</th>
								<th scope="col"><i class="fas fa-user"></i> Last</th>
								<th scope="col"><i class="fas fa-paper-plane"></i> Email</th>
								<th scope="col"><i class="fas fa-cogs"></i> Settings</th>
							</tr>
						</thead>
						<tbody>
						<?php 
							foreach ($rows as $row) {
								echo '<tr>';
									echo '<th scope="row">'.$row['user_id'].'</th>';
									echo '<td>'.$row['user'].'</td>';
									echo '<td>'.$row['first_name'].'</td>';
									echo '<td>'.$row['last_name'].'</td>';
									echo '<td>'.$row['email'].'</td>';
									echo '<td>
											<a class="btn btn-primary btn-sm" href="members.php?do=Edit&userid='.$row['user_id'].'" role="button"><i class="fas fa-pen"></i> Edit</a>
											<a class="btn btn-danger btn-sm" href="members.php?do=Delete&userid='.$row['user_id'].'" role="button"><i class="fas fa-trash-alt"></i> Delete</a>
										</td>';
								echo '</tr>';
							}
						?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<a href="members.php?do=Add" class="btn btn-primary mt-2"><i class="fas fa-user-plus"></i> Add New Member</a>
		<?php
	}elseif ($do == 'Add') {
		?>
		<div class="card">
			<h5 class="card-header"><i class="fas fa-user-plus"></i> Add New Member</h5>
			<div class="card-body">
				<form action="?do=Insert" method="POST">
					<div class="text-center">
						<img src="style/photo/users/default.png" class="rounded" alt="Cinque Terre" width="150" height="150">
					</div>
					<div class="form-row">
						<div class="form-group col-md-6">
							<label for="inputUsername"><i class="fas fa-user-nurse"></i> Username</label>
							<input type="text" name="username" class="erorrJS form-control" id="inputUsername" placeholder="User Name" autocomplete="off" required>
						</div>
						<div class="form-group col-md-6">
							<label for="inputPassword"><i class="fas fa-key"></i> Password</label>
							<input type="password" name="password" value="" class="erorrJS form-control" id="inputPassword" placeholder="password" autocomplete="new-pssword" required>
						</div>
						<div class="form-group col-md-6">
							<label for="inputFirstName"><i class="fas fa-user"></i> First Name</label>
							<input type="text" name="firstname" class="erorrJS form-control" id="FirstName" placeholder="First Name" required>
						</div>
						<div class="form-group col-md-6">
							<label for="inputLastName"><i class="fas fa-user"></i> Last Name</label>
							<input type="text" name="lastname" class="erorrJS form-control" id="inputLastName" placeholder="Last Name" required>
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail"><i class="fas fa-paper-plane"></i> Email</label>
							<input type="email" name="email" class="erorrJS form-control" id="inputEmail" placeholder="Email" required>

						</div>
						<div class="form-group col-md-6">
							<label for="inputTelephone"><i class="fas fa-phone-alt"></i> Telephone</label>
							<input type="text" name="telephone" value="+966" class="form-control" id="inputTelephone" placeholder="Telephone" disabled>
						</div>
					</div>
					<button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add New Member</button>
				</form>
			</div>
		</div>
		<?php
	}elseif ($do == 'Insert') {
		echo '<div class="card"><h5 class="card-header"><i class="fas fa-radiation"></i> Administrative message</h5><div class="card-body">';
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$username 	= $_POST['username'];
			$password 	= $_POST['password'];
			$firstname 	= $_POST['firstname'];
			$lastname 	= $_POST['lastname'];
			$email 		= $_POST['email'];
			$avatar 	= 'style/photo/users/default.png';
			$hashPass 	= sha1($_POST['password']);
			$FormError 	= array();
			if (strlen($username) < 4) {
				$FormError[] = 'Username Cant Be Less Than 4 Charactors'; 
			}
			if (strlen($username) > 20) {
				$FormError[] = 'Username Cant Be More Than 20 Charactors';
			}
			if (empty($username)) {
				$FormError[] = 'Username Cant Be Empty';
			}
			if (empty($password)) {
				$FormError[] = 'Password Cant Be Empty';
			}
			if (empty($firstname)) {
				$FormError[] = 'First Name Cant Be Empty';
			}
			if (empty($lastname)) {
				$FormError[] = 'LastName Cant Be Empty';
			}
			if (empty($email)) {
				$FormError[] = 'Email Cant Be Empty';
			}
			foreach ($FormError as $error) {
				echo '<div class="alert alert-danger" role="alert"><i class="fas fa-times"></i> '.$error.'</div>';
			}
			if (empty($FormError)) {
				$check 	= checkItem('user', 'users', $username);
				if ($check == 1) {
					echo '<div class="alert alert-danger" role="alert"><i class="fas fa-times"></i> Username exists, please choose another username</div>';
				}else{
					$stmt 	= $con->prepare("INSERT INTO users(user, password, first_name, last_name, email, avatar, date) VALUES(:zuser, :zpassword, :zfirstname, :zlastname, :zemail, :zavatar, now()) ");
					$stmt->execute(array(
										'zuser' 		=> $username,
										'zpassword'		=> $hashPass,
										'zfirstname' 	=> $firstname,
										'zlastname' 	=> $lastname,
										'zemail' 		=> $email,
										'zavatar'		=> $avatar,
										));
					echo '<div class="alert alert-success" role="alert"><i class="fas fa-check"></i> The member was added successfully</div>';
					echo '</div></div>';
				}
			}
		}else{
			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation"></i> Error</div>';
		}
	}elseif ($do == 'Edit') {
		$userid = isset($_GET['userid']) && is_numeric($_GET['userid']) ? intval($_GET['userid']) : 0;
		$stmt 	= $con->prepare("SELECT * FROM users WHERE user_id = ? LIMIT 1");
		$stmt->execute(array($userid));
		$row 	= $stmt->fetch();
		$count 	= $stmt->rowCount();
		if ($count > 0) {
		?>
		<div class="card">
			<h5 class="card-header"><i class="fas fa-user-cog"></i> Edit information</h5>
			<div class="card-body">
				<form action="?do=Update" method="POST">
					<input type="hidden" name="userid" value="<?php echo $userid; ?>">
					<div class="text-center">
						<img src="<?php echo $row['avatar']; ?>" class="rounded" alt="Cinque Terre" width="150" height="150">
					</div>
					<div class="form-row">
						<div class="form-group col-md-6">
							<label for="inputUsername"><i class="fas fa-user-nurse"></i> Username</label>
							<input type="text" name="username" value="<?php echo $row['user']; ?>" class="erorrJS form-control" id="inputUsername" placeholder="User Name" autocomplete="off" required>
						</div>
						<div class="form-group col-md-6">
							<label for="inputPassword"><i class="fas fa-key"></i> Password</label>
							<input type="hidden" name="oldpassword" value="<?php echo $row['password']; ?>">
							<input type="password" name="newpassword" value="" class="form-control" id="inputPassword" placeholder="Leave Blank If You Dont Want To Chaange" autocomplete="new-pssword">
						</div>
						<div class="form-group col-md-6">
							<label for="inputFirstName"><i class="fas fa-user"></i> First Name</label>
							<input type="text" name="firstname" value="<?php echo $row['first_name']; ?>" class="erorrJS form-control" id="FirstName" placeholder="First Name" required>
						</div>
						<div class="form-group col-md-6">
							<label for="inputLastName"><i class="fas fa-user"></i> Last Name</label>
							<input type="text" name="lastname" value="<?php echo $row['last_name']; ?>" class="erorrJS form-control" id="inputLastName" placeholder="Last Name" required>
						</div>
						<div class="form-group col-md-6">
							<label for="inputEmail"><i class="fas fa-paper-plane"></i> Email</label>
							<input type="email" name="email" value="<?php echo $row['email']; ?>" class="erorrJS form-control" id="inputEmail" placeholder="Email" required>

						</div>
						<div class="form-group col-md-6">
							<label for="inputTelephone"><i class="fas fa-phone-alt"></i> Telephone</label>
							<input type="text" name="telephone" value="+966" class="form-control" id="inputTelephone" placeholder="Telephone" disabled>
						</div>
					</div>
					<button type="submit" class="btn btn-primary"><i class="fas fa-edit"></i> Edit information</button>
				</form>
			</div>
		</div>
		<?php
		}else{
			echo '<div class="card"><h5 class="card-header"><i class="fas fa-radiation"></i> Administrative message</h5><div class="card-body">';
			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation"></i> Message Error ID</div>';
			echo '</div></div>';
		}
	}elseif ($do == 'Update') {
		echo '<div class="card"><h5 class="card-header"><i class="fas fa-radiation"></i> Administrative message</h5><div class="card-body">';
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$id 		= $_POST['userid'];
			$username 	= $_POST['username'];
			$firstname 	= $_POST['firstname'];
			$lastname 	= $_POST['lastname'];
			$email 		= $_POST['email'];
			$password 	= empty($_POST['newpassword']) ? $_POST['oldpassword'] : sha1($_POST['newpassword']);
			$FormError 	= array();
			if (strlen($username) < 4) {
				$FormError[] = 'Username Cant Be Less Than 4 Charactors'; 
			}
			if (strlen($username) > 20) {
				$FormError[] = 'Username Cant Be More Than 20 Charactors';
			}
			if (empty($username)) {
				$FormError[] = 'Username Cant Be Empty';
			}
			if (empty($firstname)) {
				$FormError[] = 'First Name Cant Be Empty';
			}
			if (empty($lastname)) {
				$FormError[] = 'LastName Cant Be Empty';
			}
			if (empty($email)) {
				$FormError[] = 'Email Cant Be Empty';
			}
			foreach ($FormError as $error) {
				echo '<div class="alert alert-danger" role="alert"><i class="fas fa-times"></i> '.$error.'</div>';
			}
			if (empty($FormError)) {
				$stmt 	= $con->prepare("UPDATE users SET user = ?, first_name = ?, last_name = ?, email = ?, password = ? WHERE user_id = ?");
				$stmt->execute(array($username, $firstname, $lastname, $email, $password, $id));
				echo '<div class="alert alert-success" role="alert"><i class="fas fa-check"></i> The data was successfully updated</div>';
				echo '</div></div>';
			}
		}else{
			echo '<div class="alert alert-danger" role="alert"><i class="fas fa-exclamation"></i> Error</div>';
		}
	}elseif ($do == 'Delete') {
		$userid = isset($_GET['userid']) && is_numeric($_GET['userid']) ? intval($_GET['userid']) : 0;
		$check 	= checkItem('user_id', 'users', $userid);
		if ($check > 0 and $userid != 1) {
			$stmt = $con->prepare("DELETE FROM users WHERE user_id = :zuser");
			$stmt->bindParam(":zuser", $userid);
			$stmt->execute();
		}else{
			echo 'This ID Is Not Exist';
		}
	}
	echo'</div></div></div>';
	include_once $templates.'footer.php';
}else{
	header('Location: index.php');
	exit();
}
ob_end_flush();
?>