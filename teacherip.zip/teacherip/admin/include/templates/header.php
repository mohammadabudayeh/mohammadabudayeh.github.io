<!DOCTYPE html>
<html dir="<?php echo $lang['Lang_dir'] ?>" lang="<?php echo $lang['Lang_html'] ?>">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<title><?php echo $lang['Lang_Title']; ?></title>
	<meta name="author" content="<?php echo $lang['Lang_Author']; ?>" />
	<meta name="description" content="<?php echo $lang['Lang_Descripti']; ?>" />
	<meta name="keywords" content="<?php echo $lang['Lang_Keywords']; ?>" />
	<link rel="icon" href="<?php echo $img; ?>fav-icon.png" />
	<link rel="apple-touch-icon" href="<?php echo $img; ?>fav-icon.png" />
	<link rel="stylesheet" href="<?php echo $css; ?>fontawesome.min.css" />
	<link rel="stylesheet" href="<?php echo $css.$lang['Lang_bootstrap']; ?>" />
	<link rel="stylesheet" href="<?php echo $css; ?>animate.min.css" />
	<link rel="stylesheet" href="<?php echo $css; ?>style.css"/>
	<link rel="stylesheet" href="<?php echo $css.$lang['Lang_Css']; ?>" />
	<script src="<?php echo $js; ?>sweetalert.min.js"></script>
	
</head>
<body>
	<div id="loading">
		<div class="spinner-border text-light" style="width: 3rem; height: 3rem;" role="status">
			<span class="sr-only">Loading...</span>
		</div>
		<div class="loading-text">
			<h2><?php echo $lang['Lang_Title']; ?></h2>
			<h6><?php echo $lang['Lang_JelApp']; ?></h6>
		</div>
	</div>