<nav class="navbar navbar-expand navbar-dark bg-dark static-top">
	<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
		<i class="fas fa-bars"></i>
	</button>
	<a class="navbar-brand mr-1" href="index.php"><?php echo $lang['Lang_NBTPC']; ?></a>
	<ul class="navbar-nav ml-auto nvbar-xp">
		<li class="nav-item dropdown no-arrow mx-1">
			<a class="nav-link" href="#">
				<span class="badge badge-danger">0</span>
				<i class="fas fa-envelope fa-fw"></i>
			</a>
		</li>
		<li class="nav-item dropdown no-arrow">
			<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				<i class="fas fa-user-circle fa-fw"></i>
			</a>
			<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
				<a class="dropdown-item" href="members.php?do=Edit&userid=<?php echo $_SESSION['ID']; ?>"><i class="fas fa-user-cog"></i> Edit Profile</a>
			<div class="dropdown-divider"></div>
				<button onclick="myFunctionLogOut()" class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</button>
				<script>
					function myFunctionLogOut() {
						swal({
							title: "<?php echo "Are you sure?"; ?>",
							icon: "warning",
							buttons: ["Cancel", "Logout!"],
							dangerMode: true,
						})
						.then((willDelete) => {
							if (willDelete) {
							window.location.href = 'logout.php';
						} else {
							//swal("Your imaginary file is safe!");
						}
						});
					}
				</script>
			</div>
		</li>
	</ul>
</nav>
<div id="wrapper">
	<ul class="sidebar navbar-nav">
		<li class="nav-item <?php echo htmlentities(basename($_SERVER['PHP_SELF']))=='dashboard.php' ? 'active' : ''; ?>">
			<a class="nav-link" href="dashboard.php">
				<i class="fas fa-fw fa-tachometer-alt"></i>
				<span>Dashboard</span>
			</a>
		</li>
		<li class="nav-item <?php echo htmlentities(basename($_SERVER['PHP_SELF']))=='category.php' ? 'active' : ''; ?>">
			<a class="nav-link" href="category.php">
				<i class="far fa-newspaper"></i>
				<span>Category</span>
			</a>
		</li>
		<li class="nav-item <?php echo htmlentities(basename($_SERVER['PHP_SELF']))=='item.php' ? 'active' : ''; ?>">
			<a class="nav-link" href="item.php">
				<i class="fas fa-sitemap"></i>
				<span>Item</span>
			</a>
		</li>
		<li class="nav-item <?php echo htmlentities(basename($_SERVER['PHP_SELF']))=='members.php' ? 'active' : ''; ?>">
			<a class="nav-link" href="members.php">
				<i class="fas fa-users"></i>
				<span>Members</span>
			</a>
		</li>
	</ul>