	<footer>
		<nav class="navbar fixed-bottom navbar-light bg-white">
			<div class="container">
				<div>
					<strong>
						<?php echo $lang['Lang_Copyrig'] ?>
					</strong>
					<b><?php echo $lang['Lang_Version'] ?></b>
				</div>
				<div>
				<?php
					if ($_COOKIE['lang']=='ar') {
						echo '<a href="?lang=en">';
						echo $lang['lang_en'];
						echo '</a>';
					}else{
						echo '<a href="?lang=ar">';
						echo $lang['lang_ar'];
						echo '</a>';
					}
				?>
				</div>
			</div>
		</nav>
	</footer>
	<script src="<?php echo $js; ?>jquery-3.4.1.min.js"></script>
	<script src="<?php echo $js; ?>bootstrap.min.js"></script>
	<script src="<?php echo $js; ?>custom.js"></script>

</body>
</html>