<?php
ob_start();
function ch_title($title){
	$output 		= ob_get_contents();
	if ( ob_get_length() > 0) { ob_end_clean(); }
	$patterns 		= array("/<title>(.*?)<\/title>/");
	$replacements 	= array("<title>$title</title>");
	$output 		= preg_replace($patterns, $replacements,$output);
	echo $output;
}

// Start message functions --
function dvwaMessagePush( $pMessage ) {
	$dvwaSession =& dvwaSessionGrab();
	if( !isset( $dvwaSession[ 'messages' ] ) ) {
		$dvwaSession[ 'messages' ] = array();
	}
	$dvwaSession[ 'messages' ][] = $pMessage;
}
// Token functions --
function checkToken( $user_token, $session_token, $returnURL ) {  # Validate the given (CSRF) token
	if( $user_token !== $session_token || !isset( $session_token ) ) {
		dvwaMessagePush( 'CSRF token is incorrect' );
		dvwaRedirect( $returnURL );
	}
}
function generateSessionToken() {  # Generate a brand new (CSRF) token
	if( isset( $_SESSION[ 'session_token' ] ) ) {
		destroySessionToken();
	}
	$_SESSION[ 'session_token' ] = md5( uniqid() );
}
function destroySessionToken() {  # Destroy any session with the name 'session_token'
	unset( $_SESSION[ 'session_token' ] );
}
function tokenField() {  # Return a field for the (CSRF) token
	return "<input type='hidden' name='user_token' value='{$_SESSION[ 'session_token' ]}' />";
}
// -- END (Token functions)

// Check Items v1.0 --
function checkItem($select, $from, $value) {
	global $con;
	$statement = $con->prepare("SELECT $select FROM $from WHERE $select = ?");
	$statement->execute(array($value));
	return $statement->rowCount();
}
// Count Number Of Items v1.0 --
function countItems($item, $table) {
	global $con;
	$statement = $con->prepare("SELECT COUNT($item) FROM $table");
	$statement->execute();
	return $statement->fetchColumn();
}
// Get Latest Records v1.0 --
function getLatest($select, $table, $order, $limit = 5) {
	global $con;
	$statement = $con->prepare("SELECT $select FROM $table ORDER BY $order DESC LIMIT $limit");
	$statement->execute();
	return $statement->fetchAll();
}