<?php
$lang = array(
    #Header.php
    "Lang_dir"      => "rtl",
    "Lang_html"     => "ar",
    "Lang_Title"    => "تيتشر اي بي",

    "Lang_Author"   => "سلطان العتيبي",
    "Lang_Descripti"=> "تيتشر اي بي موقع  يفيد مستخدمين منتجات شركة ابل – Apple . تطبيقات , شروحات , جيل بريك و نصائح, ادوات , و أخر أخبار التقنية لآبل . كل ما يخص آبل تجده هنا",
    "Lang_Keywords" => "جيلبريك, سيديا, اي او اس, ادوات , شروحات, تطبيقات جوال, تطبيقات , اب ستور, حلول , مساعدة , مساعدة , تيتشر, تويتر",
    
    "Lang_bootstrap"=> "bootstrap_rtl.min.css",
    "Lang_Css"      => "ar.css",
    "Lang_JelApp"   => "ادوات وتطبيقات جيلبريك",
    #Navbar.php
    "Lang_NBTPC"    => "تيتشر اي بي",
    "Lang_HomeN"    => "الرئيسية",
    "Lang_ToolsN"   => "ادوات",
    "Lang_AppsN"    => "تطبيقات",
    "Lang_AboutMn"  => "نبذة عني",
    #Index.php
    "Lang_Index"    => "تيتشر اي بي | الرئيسية",
    "Lang_IFSLI"    => "العثور على الروابط المختصرة",
    "Lang_TypeC"    => "اكتب الكود هنا",
    "Lang_BSToo"    => " افضل <strong>الادوات المضافة</strong>",
    "Lang_FREEI"    => "مجاني",

    "Lang_Cydia"     => " سيديا",
    "Lang_Installer" => " انستيلر",
    "Lang_Sileo"     => " سيليو",
    "Lang_Zebra"     => " زيبرا",

    "Lang_DECHER"   => " التفاصيل اضغط هنا",

    ######
    "Lang_TFANST"   => " قفل التطبيقات بالبصمة او قفل عناصر مركز التحكم.",
    "Lang_MNITBA"   => "تصغير الإشعارات في البار وشاشة القفل ",
    "Lang_AMATCS"   => "اضافة اختصارات اسفل الكيبورد نسخ ، لصق تحديد والكثير",
    "Lang_TFCYVT"   => " تغيير صوتك الى عدة اصوات اثناء المكالمة",
    "Lang_LAWSCF"   => "تعطيك ايقونة تطبيق في الشاشة الرئيسية بداخلها مكتبه مليئة ب سورسات",
    "Lang_TFANSC"   => "افضل اداة للانستقرام ",
    ######
    
    #Footer.php
    "Lang_SultanA"  => "سلطان العتيبي",
    "Lang_Copyrig"  => "جميع الحقوق محفوظة",
    "Lang_Version"  => " ١.٠",
    "lang_en"       => "English",
);