<?php
$NameWebSite = ' - '.'Teacher IP';

$lang = array(
	#Header.php
	"Lang_dir"		=> "ltr",
	"Lang_html"		=> "en",
	"Lang_Title"	=> "Title".$NameWebSite,
	"Lang_Author"	=> "",
	"Lang_Descripti"=> "",
	"Lang_Keywords"	=> "",
	"Lang_bootstrap"=> "bootstrap.min.css",
	"Lang_Css"		=> "en.css",
	"Lang_JelApp"	=> "Admin",
	#Navbar.php
	"Lang_NBTPC"	=> "Control Panel",
	"Lang_HomeN"	=> "Home",
	"Lang_ToolsN"	=> "Sections",
	"Lang_AppsN"	=> "Member",
	"Lang_AboutMn"	=> "Sing Out",
	#Index.php
	"Lang_Index"	=> "Login".$NameWebSite,

	"Lang_admin"	=> "Admin Login",
	"Lang_Username"	=> "Username",
	"Lang_Password"	=> "Password",
	"Lang_Login"	=> "Login",
	"Lang_ForgotYP"	=> "Forgot your password ?",

	#Dashboard
	"Lang_Dashboard"=> "Dashboard".$NameWebSite,
	

	#Footer.php
	"Lang_Copyrig"	=> "All rights reserved",
	"Lang_Version"	=> " 1.0",
	"lang_ar"		=> "العربية", 
);