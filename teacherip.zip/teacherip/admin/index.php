<?php
ob_start();
session_start();
$noNavbar = 'Disable Navbar view';
include_once 'initialize.php';
ch_title($lang['Lang_Index']);
if (isset($_SESSION['Username'])) {
	header('Location: dashboard.php');
	exit();
}
if( isset( $_POST[ 'Login' ] ) && isset ($_POST['username']) && isset ($_POST['password']) ) {
	checkToken( $_REQUEST[ 'user_token' ], $_SESSION[ 'session_token' ], 'index.php' );

	$user = $_POST[ 'username' ];
	$user = stripslashes( $user );
	$user = ((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"],  $user ) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : ""));

	$pass = $_POST[ 'password' ];
	$pass = stripslashes( $pass );
	$pass = ((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"],  $pass ) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : ""));
	$pass = sha1( $pass );

	$total_failed_login = 3;
	$lockout_time       = 1;
	$account_locked     = false;

	$data = $con->prepare( 'SELECT failed_login, last_login FROM users WHERE user = (:user) LIMIT 1;' );
	$data->bindParam( ':user', $user, PDO::PARAM_STR );
	$data->execute();
	$row = $data->fetch();

	if( ( $data->rowCount() == 1 ) && ( $row[ 'failed_login' ] >= $total_failed_login ) )  {

		//echo "<pre><br />This account has been locked due to too many incorrect logins.</pre>";

		$last_login = strtotime( $row[ 'last_login' ] );
		$timeout 	= $last_login + ($lockout_time * 60);
		$timenow 	= time();
		
		/*
		print "The last login was: " . date ("h:i:s", $last_login) . "<br />";
		print "The timenow is: " . date ("h:i:s", $timenow) . "<br />";
		print "The timeout is: " . date ("h:i:s", $timeout) . "<br />";
		*/
		
		if( $timenow < $timeout ) {
			$account_locked = true;
			//print "The account is locked<br />";
		}
	}

	$data = $con->prepare( 'SELECT * FROM users WHERE user = (:user) AND password = (:password) LIMIT 1;' );
	$data->bindParam( ':user', $user, PDO::PARAM_STR);
	$data->bindParam( ':password', $pass, PDO::PARAM_STR );
	$data->execute();
	$row = $data->fetch();

	if( ($data->rowCount() == 1) && ($account_locked == false) ){

/**
		$avatar 		= $row[ 'avatar' ];
		$failed_login 	= $row[ 'failed_login' ];
		$last_login 	= $row[ 'last_login' ];

		echo "<p>Welcome to the password protected area <em>{$user}</em></p>";
		echo "<img src=\"{$avatar}\" />";

		// Had the account been locked out since last login?
		if( $failed_login >= $total_failed_login ) {
			echo "<p><em>Warning</em>: Someone might of been brute forcing your account.</p>";
			echo "<p>Number of login attempts: <em>{$failed_login}</em>.<br />Last login attempt was at: <em>${last_login}</em>.</p>";
		}
**/

		$data = $con->prepare( 'UPDATE users SET failed_login = "0" WHERE user = (:user) LIMIT 1;' );
		$data->bindParam( ':user', $user, PDO::PARAM_STR );
		$data->execute();

		$_SESSION['Username'] 	= $user;
		$_SESSION['ID'] 		= $row['user_id'];
		header('Location: dashboard.php');
		exit();

	} else {
		// Login failed
		sleep( rand(2,4) );
		echo'
			<script>
				swal({
					title: "Wrong entry!",
					text: "Username and/or password incorrect.",
					icon: "error",
					button: "Ok!",
				});
			</script>
		';
		// Update bad login count
		$data = $con->prepare( 'UPDATE users SET failed_login = (failed_login + 1) WHERE user = (:user) LIMIT 1;' );
		$data->bindParam( ':user', $user, PDO::PARAM_STR );
		$data->execute();
	}

	// Set the last login time
	$data = $con->prepare( 'UPDATE users SET last_login = now() WHERE user = (:user) LIMIT 1;' );
	$data->bindParam( ':user', $user, PDO::PARAM_STR );
	$data->execute();
}

// Generate Anti-CSRF token
generateSessionToken();
?>
<script>
function validateForm() {
	var username = document.forms["LoginForm"]["username"].value;
	var password = document.forms["LoginForm"]["password"].value;
	if (username == "" || username == null,password == "" || password == null) {
		swal({
			title: "Wrong entry!",
			text: "Username and password are blank",
			icon: "error",
			button: "Ok!",
		});
		return false;
	}
}
</script>
<div class="container h-100 loginx bounceInDown animated">
	<div class="d-flex justify-content-center h-100">
		<div class="user_card">
			<h3 class="text-center"><?php echo $lang['Lang_admin'] ?></h3>
			<div class="form_container">
				<form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" name="LoginForm" onsubmit="return validateForm()" method="POST">
					<div class="input-group mb-3">
						<div class="input-group-append">
							<span class="input-group-text"><i class="fas fa-user"></i></span>
						</div>
						<input class="erorrJS form-control input_xp" type="text" name="username" placeholder="<?php echo $lang['Lang_Username'] ?>" autocomplete="off" required />
					</div>
					<div class="input-group mb-2">
						<div class="input-group-append">
							<span class="input-group-text"><i class="fas fa-key"></i></span>
						</div>
						<input class="erorrJS form-control input_xp" type="password" name="password" placeholder="<?php echo $lang['Lang_Password'] ?>" autocomplete="off" required />
					</div>
					<input class="btn login_btn" type="submit" name="Login" value="<?php echo $lang['Lang_Login'] ?>" />
					<?php echo tokenField(); ?>
				</form>
			</div>
			<div class="d-flex justify-content-center linksxp">
				<a href="#" class="btn disabled"><?php echo $lang['Lang_ForgotYP'] ?></a>
			</div>
		</div>
	</div>
</div>

<?php
include_once $templates.'footer.php';
ob_end_flush();
?>