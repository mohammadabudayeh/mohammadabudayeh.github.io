<?php
ob_start();
session_start();
include_once 'initialize.php';

	$ogurlItem 		= 'https://teacher-ip.com/privacy-policy';
	$ogimageItem 	= 'https://teacher-ip.com/style/photo/Privacy-Policy.png';
	$ogtypeItem 	= 'website';
	if ($_COOKIE['lang']=='en') {
		$keywordsItem 		= 'Privacy, Browsing, Internet Protocol (IP) address, Network scans, When you call us, information, application, On the web, Privacy policy, aid, TeacheriP, Twitter';
		$descriptionItem 	= 'Website privacy policy, terms of use.';
		$authorItem 		= 'Sultan AL-Otaibi';
		$ogtitle 			= 'Privacy policy | Teacher iP';
		$ogdescriptionI 	= 'Website privacy policy, terms of use.';
		$oglocaleItem 		= 'en_US';
	}else{
		$keywordsItem 		= 'الخصوصية ، التصفح ، عنوان بروتوكول الإنترنت (IP) ، عمليات مسح الشبكة ، عند الاتصال بنا ، المعلومات ، التطبيق ، على الويب ، سياسة الخصوصية ، المساعدة ، TeacheriP ، Twitter';
		$descriptionItem 	= 'سياسة خصوصية الموقع وشروط الاستخدام.';
		$authorItem 		= 'سلطان العتيبي';
		$ogtitle 			= 'سياسة الخصوصية | تيتشر اي بي';
		$ogdescriptionI 	= 'سياسة خصوصية الموقع وشروط الاستخدام.';
		$oglocaleItem 		= 'ar_SA';
	}
	header_Tag( $lang['Lang_Title_Privacy'].' | '.$lang['Lang_Title'],
				$keywordsItem,
				$descriptionItem,
				$authorItem,
				$ogtitle,
				$ogdescriptionI,
				$ogurlItem,
				$ogimageItem,
				$ogtypeItem,
				$oglocaleItem
			);
?>
	<div class="sb-nav-tabs-wrapper">
		<div class="container">
			<ul class="nav nav-tabs sb-nav-tabs border-0">
				<img src="style/photo/Privacyimage.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="Privacyimage" title="Privacy image" style="width: 60px; height: 60px;position: absolute;">
				<li class="nav-item">
					<a class="nav-link nav-link-theme active">
						<h1 class="font-weight-bold"><?php echo $lang['Lang_Title_Privacy']; ?></h1>
					</a>
				</li>
			</ul>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 pb-5">
				<div class="card">
					<div class="card-body text-justify font-weight-normal">
						<img src="style/photo/Privacy-Policy.png" class="img-responsive img-fluid " alt="Blue-VS-Red" title="Privacy Policy">
						<small class="text-muted float-<?php echo $lang['Lang_Langflot']; ?>">
							<i class="fas fa-calendar-alt"></i> 
							<time datetime="2020-09-20">September 20,2020</time>
						</small>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyPAC']; ?></h4>
						<p class="">
							<?php echo $lang['Lang_PrivacyWAT']; ?>
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyBROWS']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyWDND']; ?>
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyIPIA']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyAYVA']; ?>
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyANSC']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyATHS']; ?>
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyALTOS']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyAOSMC']; ?> 
							<a href="https://policies.google.com/technologies/ads" title="<?php echo $lang['Lang_PrivacyAPGADS']; ?>" target="_blank"><?php echo $lang['Lang_PrivacyCLIDH']; ?></a>.
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyADOS']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyAWAAT']; ?>
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyADNT']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyAWWNA']; ?>
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyAWYC']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyAADPB']; ?>
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyADOIT']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyAWWNS']; ?>
						</p>
						<h4 class="font-weight-bold"><?php echo $lang['Lang_PrivacyAATTP']; ?></h4>
						<p>
							<?php echo $lang['Lang_PrivacyAWTRT']; ?>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
include_once $templates . 'footer.php';
ob_end_flush();
?>