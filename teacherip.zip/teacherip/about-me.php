<?php
ob_start();
session_start();
include_once 'initialize.php';
	$ogurlItem 		= 'https://teacher-ip.com/about-me';
	$ogimageItem 	= 'https://teacher-ip.com/style/photo/fav-icon.png';
	$ogtypeItem 	= 'website';
	header_Tag( $lang['Lang_AMeTitle'].' | '.$lang['Lang_Title'],
				$lang['Lang_AMekeywords'],
				$lang['Lang_AMedescript'],
				$lang['Lang_AMeauthor'],
				$lang['Lang_AMeogtitle'],
				$lang['Lang_AMeogdescrip'],
				$ogurlItem,
				$ogimageItem,
				$ogtypeItem,
				$lang['Lang_AMeoglocale']
			);

?>
	<div class="sb-nav-tabs-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<ul class="nav nav-tabs sb-nav-tabs border-0">
						<img src="<?php echo $UrlXp; ?>style/photo/fav-icon.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="Cinque Terre" style="width: 60px; height: 60px;position: absolute;">
						<li class="nav-item">
							<a class="nav-link nav-link-theme active">
								<h2 class="font-weight-bold"><?php echo $lang['Lang_AMeAboutMe']; ?></h2>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-lg-4 mb-3">
				<div class="card shadow">
					<div class="card-body text-center">
						<img src="<?php echo $UrlXp; ?>style/photo/fav-icon.png" class="rounded mx-auto img-thumbnail" alt="<?php echo $lang['Lang_AMeImageTS']; ?>">
						<button type="button" class="btn btn-outline-primary btn-block mt-3 font-weight-bold"><i class="fas fa-file-pdf" style="color: red;"></i> <?php echo $lang['Lang_AMeDOWNLOADR']; ?></button>
					</div>
				</div>
			</div>
			<div class="col-lg-8 mb-3">
				<div class="card shadow">
					<div class="card-body text-justify">
						<h1 class="font-weight-bold"><?php echo $lang['Lang_AMe1']; ?></h1>
						<h3 class="text-muted" style="padding-bottom: 20px;font-size: 20px;"><?php echo $lang['Lang_AMe2']; ?></h3>
						<p class="card-text font-weight-normal"><?php echo $lang['Lang_AMe3']; ?></p>
						<div class="row">
							<div class="col-sm-6">
								<ul class="list-group list-group-flush">
									<li class="list-group-item d-flex justify-content-between align-items-center">
										<?php echo $lang['Lang_AMeAge']; ?>
										<span><?php echo $lang['Lang_AMeAgeX']; ?></span>
									</li>
									<li class="list-group-item d-flex justify-content-between align-items-center">
										<?php echo $lang['Lang_AMeAddress']; ?>
										<span><?php echo $lang['Lang_AMeAddressX']; ?></span>
										</li>
									<li class="list-group-item d-flex justify-content-between align-items-center">
										<?php echo $lang['Lang_AMeEmail']; ?>
										<span>t@teacher-ip.com</span>
									</li>
								</ul>
							</div>
							<div class="col-sm-6">
								<ul class="list-group list-group-flush">
									<li class="list-group-item d-flex justify-content-between align-items-center">
										<?php echo $lang['Lang_AMePhone']; ?>
										<span><?php echo $lang['Lang_AMePhoneX']; ?></span>
									</li>
									<li class="list-group-item d-flex justify-content-between align-items-center">
										<?php echo $lang['Lang_AMeWebsite']; ?>
										<span>teacher-ip.com</span>
										</li>
									<li class="list-group-item d-flex justify-content-between align-items-center">
										<?php echo $lang['Lang_AMeNationali']; ?>
										<span><?php echo $lang['Lang_AMeNationaliX']; ?></span>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
include_once 'include/templates/footer.php';
ob_end_flush();
?>