<?php
ob_start();
session_start();
include_once 'initialize.php';

	$ogurlItem 		= 'https://teacher-ip.com/';
	$ogimageItem 	= 'https://teacher-ip.com/style/photo/fav-icon.png';
	$ogtypeItem 	= 'website';
	if ($_COOKIE['lang']=='en') {
		$keywordsItem 		= 'jailbreaking, Cydia, iOS, tools, uses, Mobile app, application, App Store, solution, aid, Publishing, TeacheriP, Twitter';
		$descriptionItem 	= 'Teacher iP is a website that benefits users of Apple products. Applications, explanations, Jailbreak, tips, tools, and the latest technology news for Apple.';
		$authorItem 		= 'Sultan AL-Otaibi';
		$ogtitle 			= 'Teacher iP';
		$ogdescriptionI 	= 'It displays the latest tools and updates for the jailbreak';
		$oglocaleItem 		= 'en_US';
	}else{
		$keywordsItem 		= 'جيلبريك, سيديا, اي او اس, ادوات , شروحات, تطبيقات جوال, تطبيقات , اب ستور, حلول , مساعدة , مساعدة , تيتشر, تويتر';
		$descriptionItem 	= 'تيتشر اي بي موقع  يفيد مستخدمين منتجات شركة ابل – Apple . تطبيقات , شروحات , جيل بريك و نصائح, ادوات , و أخر أخبار التقنية لآبل . كل ما يخص آبل تجده هنا';
		$authorItem 		= 'سلطان العتيبي';
		$ogtitle 			= 'تيتشر اي بي';
		$ogdescriptionI 	= 'يعرض اخر الادوات والتحديثات للجيلبريك';
		$oglocaleItem 		= 'ar_SA';
	}
	header_Tag( $lang['Lang_Title'],
				$keywordsItem,
				$descriptionItem,
				$authorItem,
				$ogtitle,
				$ogdescriptionI,
				$ogurlItem,
				$ogimageItem,
				$ogtypeItem,
				$oglocaleItem
			);
?>
	<div class="sb-nav-tabs-wrapper">
		<div class="container">
			<ul class="nav nav-tabs sb-nav-tabs border-0">
				<li class="nav-item">
					<a class="nav-link nav-link-theme active">
						<h1><i class="fas fa-tools"></i><?php echo $lang['Lang_BSToo'] ?></h1>
					</a>
				</li>
			</ul>
		</div>
	</div>
	<div class="container">
		<div class="row pt-5">
			<div class="col-lg-4 col-sm-6 mb-30 pb-5 xpstep">
				<div class="card">
					<div class="position-absolute">
						<span class="badge badge-success ml-auto small badge-pill"><?php echo $lang['Lang_FREEI'] ?></span>
					</div>
					<img src="<?php echo $img; ?>itame/A-Shields.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="A-Shields" style="width: 90px; height: 90px; margin-top: -45px;">
					<div class="card-body text-center">
						<h3 class="card-title pt-1">A-Shields</h3>
						<p class="card-text text-sm">
							<?php echo $lang['Lang_TFANST'] ?>
						</p>
						<a href="cydia://url/https://cydia.saurik.com/api/share#?source=https://repo.co.kr/" target="_blank" class="btn btn-primary btn-block btn-sm" role="button" title="saurik.com">
							<img src="<?php echo $img; ?>itame/cydia.png" alt="Cydia" width="25" height="25" class="rounded-circle">
							<?php echo $lang['Lang_Cydia'] ?>
						</a>
						<a href="installer://add/repo=https://repo.co.kr/" target="_blank" class="btn btn-primary btn-block btn-sm" role="button" title="repo.co.kr">
							<img width="25" height="25" src="<?php echo $img; ?>itame/installer.png" alt="Installer" class="rounded-circle">
							<?php echo $lang['Lang_Installer'] ?>
						</a>
						<a href="sileo://source/https://repo.co.kr/" target="_blank" class="btn btn-primary btn-block btn-sm" role="button" title="repo.co.kr">
							<img src="<?php echo $img; ?>itame/sileo.png" alt="Sileo" width="25" height="25" class="rounded-circle">
							<?php echo $lang['Lang_Sileo'] ?>
						</a>
						<a href="zbra://sources/add/https://repo.co.kr/" target="_blank" class="btn btn-primary btn-block btn-sm" role="button" title="repo.co.kr">
							<img src="<?php echo $img; ?>itame/zebra.png" alt="Zebra" width="25" height="25" class="rounded-circle">
							<?php echo $lang['Lang_Zebra'] ?>
						</a>
						<a href="<?php echo $UrlXp; ?>tools/A-Shields" class="btn btn-primary btn-block btn-sm" role="button" title="A-Shields"><i class="fa fa-angle-double-left"></i>
							<?php echo $lang['Lang_DECHER'] ?>
						</a>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mb-30 pb-5 xpstep">
				<div class="card pricexp">
					<div class="position-absolute">
						<span class="badge badge-warning ml-auto small badge-pill">$1.99</span>
					</div>
					
					<img src="<?php echo $img; ?>itame/TinyBanners.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="TinyBanners" style="width: 90px; height: 90px; margin-top: -45px;">
					<div class="card-body text-center">
						<h3 class="card-title pt-1">TinyBanners</h3>
						<p class="card-text text-sm">
							<?php echo $lang['Lang_MNITBA'] ?>
						</p>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="cydia://url/https://cydia.saurik.com/api/share#?source=https://repo.packix.com/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/cydia.png" alt="Cydia" class="rounded-circle"><?php echo $lang['Lang_Cydia'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="installer://add/repo=https://repo.packix.com/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/installer.png" alt="Installer" class="rounded-circle"><?php echo $lang['Lang_Installer'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="sileo://source/https://repo.packix.com/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/sileo.png" alt="Sileo" class="rounded-circle"><?php echo $lang['Lang_Sileo'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="zbra://sources/add/https://repo.packix.com/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/zebra.png" alt="Zebra" class="rounded-circle"><?php echo $lang['Lang_Zebra'] ?></a>
						<a class="btn btn-primary btn-block btn-sm" href="<?php echo $UrlXp; ?>tools/TinyBanners" role="button"><i class="fa fa-angle-double-left"></i><?php echo $lang['Lang_DECHER'] ?></a>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mb-30 pb-5 xpstep">
				<div class="card">
					<div class="position-absolute">
						<span class="badge badge-success ml-auto small badge-pill"><?php echo $lang['Lang_FREEI'] ?></span>
					</div>
					
					<img src="<?php echo $img; ?>itame/DockX.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="Cinque Terre" style="width: 90px; height: 90px; margin-top: -45px;">
					<div class="card-body text-center">
						<h3 class="card-title pt-1">DockX</h3>
						<p class="card-text text-sm">
							<?php echo $lang['Lang_AMATCS'] ?>
						</p>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="cydia://url/https://cydia.saurik.com/api/share#?source=http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/cydia.png" alt="Cydia" class="rounded-circle"><?php echo $lang['Lang_Cydia'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="installer://add/repo=http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/installer.png" alt="Installer" class="rounded-circle"><?php echo $lang['Lang_Installer'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="sileo://source/http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/sileo.png" alt="Sileo" class="rounded-circle"><?php echo $lang['Lang_Sileo'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="zbra://sources/add/http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/zebra.png" alt="Zebra" class="rounded-circle"><?php echo $lang['Lang_Zebra'] ?></a>
						<a class="btn btn-primary btn-block btn-sm" href="<?php echo $UrlXp; ?>tools/DockX" role="button"><i class="fa fa-angle-double-left"></i><?php echo $lang['Lang_DECHER'] ?></a>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mb-30 pb-5 xpstep">
				<div class="card pricexp">
					<div class="position-absolute">
						<span class="badge badge-warning ml-auto small badge-pill">$2.99</span>
					</div>
					
					<img src="<?php echo $img; ?>itame/VoiceChangerX.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="Cinque Terre" style="width: 90px; height: 90px; margin-top: -45px;">
					<div class="card-body text-center">
						<h3 class="card-title pt-1">VoiceChanger XS (iOS 11/12/13)</h3>
						<p class="card-text text-sm">
							<?php echo $lang['Lang_TFCYVT'] ?>
						</p>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="cydia://url/https://cydia.saurik.com/api/share#?source=http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/cydia.png" alt="Cydia" class="rounded-circle"><?php echo $lang['Lang_Cydia'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="installer://add/repo=http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/installer.png" alt="Installer" class="rounded-circle"><?php echo $lang['Lang_Installer'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="sileo://source/http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/sileo.png" alt="Sileo" class="rounded-circle"><?php echo $lang['Lang_Sileo'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="zbra://sources/add/http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/zebra.png" alt="Zebra" class="rounded-circle"><?php echo $lang['Lang_Zebra'] ?></a>
						<a class="btn btn-primary btn-block btn-sm" href="<?php echo $UrlXp; ?>tools/VoiceChangerX" role="button"><i class="fa fa-angle-double-left"></i><?php echo $lang['Lang_DECHER'] ?></a>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mb-30 pb-5 xpstep">
				<div class="card">
					<div class="position-absolute">
						<span class="badge badge-success ml-auto small badge-pill"><?php echo $lang['Lang_FREEI'] ?></span>
					</div>
					
					<img src="<?php echo $img; ?>itame/RepoFinder.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="Cinque Terre" style="width: 90px; height: 90px; margin-top: -45px;">
					<div class="card-body text-center">
						<h3 class="card-title pt-1">RepoFinder</h3>
						<p class="card-text text-sm">
							<?php echo $lang['Lang_LAWSCF'] ?>
						</p>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="cydia://url/https://cydia.saurik.com/api/share#?source=https://repo.packix.com/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/cydia.png" alt="Cydia" class="rounded-circle"><?php echo $lang['Lang_Cydia'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="installer://add/repo=https://repo.packix.com/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/installer.png" alt="Installer" class="rounded-circle"><?php echo $lang['Lang_Installer'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="sileo://source/https://repo.packix.com/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/sileo.png" alt="Sileo" class="rounded-circle"><?php echo $lang['Lang_Sileo'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="zbra://sources/add/https://repo.packix.com/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/zebra.png" alt="Zebra" class="rounded-circle"><?php echo $lang['Lang_Zebra'] ?></a>
						<a class="btn btn-primary btn-block btn-sm" href="<?php echo $UrlXp; ?>tools/RepoFinder" role="button"><i class="fa fa-angle-double-left"></i><?php echo $lang['Lang_DECHER'] ?></a>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mb-30 pb-5 xpstep">
				<div class="card">
					<div class="position-absolute">
						<span class="badge badge-success ml-auto small badge-pill"><?php echo $lang['Lang_FREEI'] ?></span>
					</div>
					
					<img src="<?php echo $img; ?>itame/Rhino.png" class="box-shadow bg-white rounded-circle text-center mx-auto" alt="Cinque Terre" style="width: 90px; height: 90px; margin-top: -45px;">
					<div class="card-body text-center">
						<h3 class="card-title pt-1">Rhino</h3>
						<p class="card-text text-sm">
							<?php echo $lang['Lang_TFANSC'] ?>
						</p>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="cydia://url/https://cydia.saurik.com/api/share#?source=http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/cydia.png" alt="Cydia" class="rounded-circle"><?php echo $lang['Lang_Cydia'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="installer://add/repo=http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/installer.png" alt="Installer" class="rounded-circle"><?php echo $lang['Lang_Installer'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="sileo://source/http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/sileo.png" alt="Sileo" class="rounded-circle"><?php echo $lang['Lang_Sileo'] ?></a>
						<a target="_blank" class="btn btn-primary btn-block btn-sm" href="zbra://sources/add/http://apt.thebigboss.org/repofiles/cydia/" role="button"><img width="25" height="25" src="<?php echo $img; ?>itame/zebra.png" alt="Zebra" class="rounded-circle"><?php echo $lang['Lang_Zebra'] ?></a>
						<a class="btn btn-primary btn-block btn-sm" href="<?php echo $UrlXp; ?>tools/Rhino" role="button"><i class="fa fa-angle-double-left"></i><?php echo $lang['Lang_DECHER'] ?></a>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
include_once $templates . 'footer.php';
ob_end_flush();
?>