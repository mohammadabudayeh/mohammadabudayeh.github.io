<?php
$nameWebsite    = ' | Teacher IP';
$webSiteUrl     = 'https://teacher-ip.com/'; 

$lang = array(
    #Header.php
    "Lang_dir"      => "ltr",
    "Lang_html"     => "en",
    "Lang_title2"   => " | Teacher IP",
    "Lang_Title"    => "Teacher IP",
    "Lang_Descripti"=> "Teacher iP is a website that benefits users of Apple products. Applications, explanations, Jailbreak, tips, tools, and the latest technology news for Apple.",
    "Lang_Keywords" => "jailbreaking, Cydia, iOS, tools, uses, Mobile app, application, App Store, solution, aid, Publishing, TeacheriP, Twitter",
    "Lang_Author"   => "Sultan AL-Otaibi",

    "Lang_ogtitle"  => "Home".$nameWebsite,
    "Lang_ogdescrip"=> "Teacher iP is a website that benefits users of Apple products. Applications, explanations, Jailbreak, tips, tools, and the latest technology news for Apple.",
    "Lang_ogurl"    => $webSiteUrl,
    "Lang_ogimage"  => "https://teacher-ip.com/style/photo/fav-icon.png",
    "Lang_ogtype_w" => "website",
    "Lang_oglocale" => "en_US",


    
    "Lang_bootstrap"=> "bootstrap.min.css",
    "Lang_Css"      => "en.css",
    "Lang_JelApp"   => "Jailbreak & application",

        #Index Header_Tag:

    #Navbar.php
    "Lang_NBTPC"    => "Teacher IP",
    "Lang_HomeN"    => "Home",
    "Lang_ToolsN"   => "Tools",
    "Lang_Privacy"  => "Privacy",
    "Lang_AppsN"    => "Apps",
    "Lang_AboutMn"  => "About Me",

    #Index.php
    "Lang_Index"    => "Teacher IP | Home",
    "Lang_IFSLI"    => "Find short links",
    "Lang_TypeC"    => "Type the code here",
    "Lang_BSToo"    => " Best <strong>Tools</strong>",
    "Lang_FREEI"    => "Free",

    "Lang_Cydia"     => " Cydia",
    "Lang_Installer" => " Installer",
    "Lang_Sileo"     => " Sileo",
    "Lang_Zebra"     => " Zebra",

    "Lang_DECHER"   => " Details click here",

    ######
    "Lang_TFANST"   => "Lock apps with fingerprint or control center items, Wi-Fi, and more.",
    "Lang_MNITBA"   => "Minimize notifications in the bar and lock screen Control color the notification Control the display.",
    "Lang_AMATCS"   => "Add shortcuts to the bottom of the keyboard, copy, paste, select, and much more",
    "Lang_TFCYVT"   => "Tool function Change your voice to several voices during the call, compatible with | ios11",
    "Lang_LAWSCF"   => "It gives you an application icon in the main screen with a library full of sursat inside",
    "Lang_TFANSC"   => "The best tool for Instagram",
    ######
    
    #Footer.php
    "Lang_SultanA"  => "Sultan AL-Otaibi",
    "Lang_Copyrig"  => "All rights reserved",
    "Lang_Version"  => " 2.0",
    "lang_ar"       => "العربية", 
    "lang_AbuDayeh" => "AbuDayeh",



    #tools/index.php
    "Lang_TITnITLE"     => "Tools",
    "Lang_TIkeywords"   => "Tools, Presence of tools, Jailbreak tools, Download tools, Protection tools, Protect your phone, IPhone protection, Customize, Development, Phone tools, TeacheriP, Twitter",
    "Lang_TIdescript"   => "Teacher IP is the fastest place to get the tweak you want, and tools.",
    "Lang_TIauthor"     => "Sultan AL-Otaibi",
    "Lang_TIogtitle"    => "Tools | Teacher iP",
    "Lang_TIogdescrip"  => "Teacher IP is the fastest place to get the tweak you want.",
    "Lang_TIoglocale"   => "en_US",
    "Lang_TIH1title"    => "Tools",

    #Privacy.php
    "Lang_Title_Privacy"    => "Privacy policy",
    "Lang_PrivacyPAC"       => "Privacy and confidentiality of information",
    "Lang_PrivacyWAT"       => "We, at TeacherIP, appreciate your concerns and your interest in the privacy of your data on the Internet. This policy has been prepared to help you understand the nature of the data that we collect from you when you visit our website and how we deal with this personal data.",
    "Lang_PrivacyBROWS"     => "Browsing",
    "Lang_PrivacyWDND"      => "We did not design this site in order to collect your personal data from your computer while you browse this site, but only the data provided by you will be used with your knowledge and of your own free will.",
    "Lang_PrivacyIPIA"      => "Internet Protocol (IP) address",
    "Lang_PrivacyAYVA"      => "Anytime you visit any website, including this site, the host server will record your Internet Protocol (IP) address, the date and time of the visit, the type of Internet browser you use and the URL of any website that refers you to this site. On the web.",
    "Lang_PrivacyANSC"      => "Network scans",
    "Lang_PrivacyATHS"      => "The surveys that we do directly on the network enable us to collect specific data such as the data required of you regarding your view and feeling towards our site. Your responses are of utmost importance, and we are appreciated as they enable us to improve the level of our site, and you have complete freedom and choice in providing data related to your name and data. Other.",
    "Lang_PrivacyALTOS"     => "Links to other sites on the Internet",
    "Lang_PrivacyAOSMC"     => "Our site may contain links to other sites on the Internet. Or advertisements from other sites such as Google AdSense and we are not responsible for the methods of data collection by those sites. You can view the privacy policies and contents of those sites that are accessed through any link within this site. We may use third-party advertising companies to display ads when you visit our website. These companies have the right to use information about your visits to this site and other websites (except for the name, address, e-mail address, or phone number), in order to provide advertisements about the goods and services that interest you. If you would like more information on this matter and also if you would like to know your options to prevent this information from being used by these companies, please",
    "Lang_PrivacyCLIDH"     => "click here",
    "Lang_PrivacyAPGADS"    => "Privacy Google Ads",
    "Lang_PrivacyADOS"      => "Disclosure of information",
    "Lang_PrivacyAWAAT"     => "We will maintain at all times the privacy and confidentiality of all personal data that we obtain. This information will not be disclosed unless it is required by any law or when we believe in good faith that such a procedure will be required or desirable to comply with the law, or to defend or protect the property rights of this site or the beneficiaries of it.",
    "Lang_PrivacyADNT"      => "Data necessary to carry out the transactions requested by you",
    "Lang_PrivacyAWWNA"     => "When we need any of your data, we will ask you to provide it of your own free will. As this information will help us in contacting you and carrying out your requests, wherever possible. The data provided by you will never be sold to any third party for the purpose of marketing it for his own benefit without obtaining your prior and written consent unless this is done on the basis that it is within collective data used for statistical purposes and research without including any data that can be used to identify you.",
    "Lang_PrivacyAWYC"      => "When you call us",
    "Lang_PrivacyAADPB"     => "All data provided by you will be treated as confidential. The forms that are submitted directly on the network require providing data that will help us improve our site. The data provided by you will be used to respond to all your inquiries, comments, or requests by this site or any of its affiliated sites.",
    "Lang_PrivacyADOIT"     => "Disclosure of information to any third party",
    "Lang_PrivacyAWWNS"     => "We will not sell, trade, rent, or disclose any information for the benefit of any third party outside this site, or its affiliated sites. The information will be disclosed only in the event of an order to do so by any judicial or regulatory authority.",
    "Lang_PrivacyAATTP"     => "Amendments to the policy of confidentiality and privacy of information",
    "Lang_PrivacyAWTRT"     => "We reserve the right to amend the terms and conditions of the policy of confidentiality and privacy of information if necessary and when appropriate. The amendments will be implemented here or on the main privacy policy page, and you will be continuously notified of the data that we have obtained, how we will use it and who will provide it with this data.",
    


    #about-me.php:
    "Lang_AMeTitle"     => "About Me",
    "Lang_AMekeywords"  => "About Me, IPhone application, developer, Phone, Address, Nationality, Email, Age, Website, DOWNLOAD RESUME",
    "Lang_AMedescript"  => "An introductory briefing about who I am, what I do, and what is my field of specialization, Sultan Al-Otaibi",
    "Lang_AMeauthor"    => "Sultan AL-Otaibi",
    "Lang_AMeogtitle"   => "About Me | Teacher iP",
    "Lang_AMeogdescrip" => "An introductory briefing about who I am",
    "Lang_AMeoglocale"  => "en_US",
    "Lang_AMeAboutMe"   => "About Me",
    "Lang_AMeDOWNLOADR" => "DOWNLOAD RESUME",
    "Lang_AMe1"         => "HI I'M <span style='color:#007bff;'>Sultan Al-Otaibi</span>",
    "Lang_AMe2"         => "IPhone application developer",
    "Lang_AMe3"         => "Hi! I am Sultan Al-Otaibi. IPhone application developer with over 8 years of experience. Experienced in all stages of the jailbreak project development cycle. Strong background in management and leadership, I love to help people and spread new developments.",
    "Lang_AMeAge"       => "Age:",
    "Lang_AMeAddress"   => "Address:",
    "Lang_AMeEmail"     => "Email:",
    "Lang_AMePhone"     => "Phone:",
    "Lang_AMeWebsite"   => "Website:",
    "Lang_AMeNationali" => "Nationality:",
    "Lang_AMeAgeX"       => "27",
    "Lang_AMeAddressX"   => "Saudi Arabia",
    "Lang_AMePhoneX"     => "+966 55555555",
    "Lang_AMeNationaliX" => "Saudi",







    #tools Element:
    "Lang_T_Description"=> "Description",
    "Lang_T_DescripText"=> "A-Shields helps protect your device.<br> A-Shields allow you to lock the Connectivity Modules in the Control Center or lock your apps. And you're connected to a specific WiFi network, you can turn off protection.",
    "Lang_T_PRICE"      => "PRICE",
    "Lang_T_RELEASED"   => "RELEASED",
    "Lang_T_VERSION"    => "VERSION",
    "Lang_T_Repository" => "Repository",
    "Lang_T_Developer"  => "Developer",
    "Lang_T_Source"     => "Source code",



    "Lang_Langflot" =>"right",
    "Lang_ML_Lang"  =>"ml",









    #Itesm tools Desc:
    "Lang_T_D_TinyBanners"  =>"TinyBanners is configurable, which means you can control how your notification banners look when they materialize. In the screenshot examples above, you’ll notice that the banners can be resized a multitude of ways such that they cover as little of the surrounding area as possible.",
    "Lang_T_D_TinyDockX"  =>"DockX is a relatively simple and sleek tweak that can supercharge the native typing experience on any jailbroken iPhone running iOS 12 or 13. It’s worth noting that the tweak only works with the native keyboard, which means third-party alternatives from the App Store aren’t supported.",
    "Lang_T_D_VoiceChangerX"  =>"Change your voice during a call directly, the first live voice changer on iPhone",
    "Lang_T_D_RepoFinder"  =>"RepoFinder is an app here to bring you a seamless way to add all of your favorite repositories right into the package manager of your choice.",
    "Lang_T_D_Rhino"  =>"Rhino is the first Instagram tweak that can save live videos and view unsent messages! Access tweak settings on the settings page.",

);