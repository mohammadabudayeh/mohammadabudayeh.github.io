<?php
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
if(!empty($_GET['lang'])){
	$_COOKIE['lang'] = htmlspecialchars($_GET['lang']) === 'en' ? 'en' : 'ar';
}elseif(empty($_COOKIE['lang'])){
	$_COOKIE['lang'] = $lang;
}

setcookie('lang', $_COOKIE['lang'], time() + (86400 * 7), '/');
require_once $_COOKIE['lang'] . ".php";