<nav class="navbar fixed-top navbar-expand-lg navbar-light bg-white">
	<div class="container">
		<a class="navbar-brand" href="<?php echo $UrlXpRe; ?>"><?php echo $lang['Lang_NBTPC']; ?></a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav">
				<li class="nav-item active">
					<a class="nav-link" href="<?php echo $UrlXpRe; ?>"><i class="fas fa-home"></i> <?php echo $lang['Lang_HomeN']; ?> <span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo $UrlXpRe ?>tools"><i class="fas fa-hammer"></i> <?php echo $lang['Lang_ToolsN']; ?></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo $UrlXpRe ?>privacy-policy"><i class="fas fa-balance-scale"></i> <?php echo $lang['Lang_Privacy']; ?></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo $UrlXpRe ?>about-me"><i class="fas fa-address-card"></i> <?php echo $lang['Lang_AboutMn']; ?></a>
				</li>
			</ul>
		</div>
	</div>
</nav>