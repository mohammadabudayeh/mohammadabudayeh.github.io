	<div class="masthead">
		<div class="container">
			<h2 class="text-center text-white">
				<?php echo $lang['Lang_SultanA'] ?>
			</h2>
			<div class="d-flex justify-content-center">
				<a target="_blank" class="footer-social-link d-inline-flex mx-3 justify-content-center align-items-center text-white rounded-circle shadow btn btn-twitter" href="https://twitter.com/TeacheriP">
					<i class="fab fa-twitter"></i>
				</a>
				<a target="_blank" class="footer-social-link d-inline-flex mx-3 justify-content-center align-items-center text-white rounded-circle shadow btn btn-instagram" href="https://www.instagram.com/TeacheriP/">
					<i class="fab fa-instagram"></i>
				</a>
				<a target="_blank" class="footer-social-link d-inline-flex mx-3 justify-content-center align-items-center text-white rounded-circle shadow btn btn-snapchat" href="#">
					<i class="fab fa-snapchat-ghost"></i>
				</a>
			</div>
		</div>
	</div>
	<footer>
		<nav class="navbar fixed-bottom navbar-light bg-white">
			<div class="container">
				<div>
					<strong>
						<?php echo $lang['Lang_Copyrig'] ?>
					</strong>
					<b><?php echo $lang['Lang_Version'] ?> &copy; 
						<a href="https://abudayeh.me" title="Mohammad AbuDayeh" target="_blank"><?php echo $lang['lang_AbuDayeh'] ?></a>
					</b>
				</div>
				<div>
				<?php
					if ($_COOKIE['lang']=='ar') {
						echo '<a href="?lang=en">';
						echo $lang['lang_en'];
						echo '</a>';
					}else{
						echo '<a href="?lang=ar">';
						echo $lang['lang_ar'];
						echo '</a>';
					}
				?>
				</div>
			</div>
		</nav>
	</footer>
	<script src="<?php echo $js; ?>jquery-3.4.1.min.js"></script>
	<script src="<?php echo $js; ?>bootstrap.min.js"></script>
	<script src="<?php echo $js; ?>custom.js"></script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-178402945-1"></script>
	<script>
	window.dataLayer = window.dataLayer || [];
	function gtag(){dataLayer.push(arguments);}
	gtag('js', new Date());

	gtag('config', 'UA-178402945-1');
	</script>

</body>
</html>