<?php
ob_start();
function header_Tag($title, $keywords, $description, $author, $og_title, $og_description, $og_url, $og_image, $og_type, $og_locale){
	$output 		= ob_get_contents();
	if ( ob_get_length() > 0) { ob_end_clean(); }
	$patterns 		= array(
						"/<title>(.*?)<\/title>/",
						"/<meta name=\"keywords\" content=\"(.*?)\" \/>/",
						"/<meta name=\"description\" content=\"(.*?)\" \/>/",
						"/<meta name=\"author\" content=\"(.*?)\" \/>/",
						"/<meta property=\"og:title\" content=\"(.*?)\" \/>/",
						"/<meta property=\"og:description\" content=\"(.*?)\" \/>/",
    					"/<meta property=\"og:url\" content=\"(.*?)\" \/>/",
    					"/<meta property=\"og:image\" content=\"(.*?)\" \/>/",
						"/<meta property=\"og:type\" content=\"(.*?)\" \/>/",
						"/<meta property=\"og:locale\" content=\"(.*?)\" \/>/"
					);
	$replacements 	= array(
						"<title>$title</title>",
						"<meta name=\"keywords\" content=\"$keywords\" />",
						"<meta name=\"description\" content=\"$description\" />",
						"<meta name=\"author\" content=\"$author\" />",
						"<meta property=\"og:title\" content=\"$og_title\" />",
						"<meta property=\"og:description\" content=\"$og_description\" />",
						"<meta property=\"og:url\" content=\"$og_url\" />",
						"<meta property=\"og:image\" content=\"$og_image\" />",
						"<meta property=\"og:type\" content=\"$og_type\" />",
						"<meta property=\"og:locale\" content=\"$og_locale\" />"
					);
	$output 		= preg_replace($patterns, $replacements,$output);
	echo $output;
}