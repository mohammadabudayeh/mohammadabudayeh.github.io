<?php
//include_once 'connect.php';
$UrlXp 		= "https://".$_SERVER["SERVER_NAME"].substr($_SERVER["PHP_SELF"],0,strrpos($_SERVER["PHP_SELF"],"/"))."/";
$UrlXpRe 	= str_replace('tools/','',$UrlXp);
$function   = 'include/function/';
$templates  = 'include/templates/';
$language	= 'include/language/';
$css      	= $UrlXpRe . 'style/stylesheets/';
$js       	= $UrlXpRe . 'style/javascript/';
$img      	= $UrlXpRe . 'style/photo/';

include_once $function .'function.php';
include_once $language . 'language.php';
include_once $templates . 'header.php';
if(!isset($noNavbar)){include_once $templates . 'navbar.php';}